<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'

type Cat = {
  id: number
  name: string
  breed: string
  birthday: string
  gender: string
  personality: string
  notes: string
  photo_data: string
  created_at: string
}

type CatDraft = Omit<Cat, 'id' | 'created_at'>

const apiBaseUrl = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '')
const page = ref<'home' | 'list' | 'detail'>('home')
const cats = ref<Cat[]>([])
const selectedCat = ref<Cat | null>(null)
const selectedCatId = ref<number | null>(null)
const isLoading = ref(false)
const isLoadingDetail = ref(false)
const isSaving = ref(false)
const listError = ref('')
const detailError = ref('')
const saveError = ref('')
const photoError = ref('')
const notice = ref('')
const showForm = ref(false)
const catDraft = ref<CatDraft>(emptyDraft())
const catCount = computed(() => cats.value.length)

function emptyDraft(): CatDraft {
  return { name: '', breed: '', birthday: '', gender: '', personality: '', notes: '', photo_data: '' }
}

async function responseError(response: Response): Promise<string> {
  try {
    const body = await response.json() as { detail?: string }
    if (body.detail) return body.detail
  } catch {
    // Use the HTTP status message if the server did not return JSON.
  }
  return `请求失败（HTTP ${response.status}）`
}

async function loadCats() {
  isLoading.value = true
  listError.value = ''
  try {
    const response = await fetch(`${apiBaseUrl}/api/cats`)
    if (!response.ok) throw new Error(await responseError(response))
    cats.value = await response.json() as Cat[]
  } catch (error) {
    listError.value = error instanceof Error
      ? `${error.message}。请确认后端正在运行，再试一次。`
      : '暂时无法读取档案，请确认后端正在运行后重试。'
  } finally {
    isLoading.value = false
  }
}

function enterArchive() {
  page.value = 'list'
  void loadCats()
}

function returnHome() {
  page.value = 'home'
  selectedCat.value = null
  selectedCatId.value = null
  detailError.value = ''
  showForm.value = false
}

function openCreateForm() {
  catDraft.value = emptyDraft()
  saveError.value = ''
  photoError.value = ''
  showForm.value = true
}

function closeCreateForm() {
  if (isSaving.value) return
  showForm.value = false
  saveError.value = ''
  photoError.value = ''
}

function choosePhoto(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  photoError.value = ''
  if (!file) return
  if (!file.type.startsWith('image/')) {
    photoError.value = '请选择图片文件。'
    input.value = ''
    return
  }
  if (file.size > 2 * 1024 * 1024) {
    photoError.value = '图片请控制在 2 MB 以内。'
    input.value = ''
    return
  }

  const reader = new FileReader()
  reader.onload = () => { catDraft.value.photo_data = String(reader.result || '') }
  reader.onerror = () => { photoError.value = '读取图片失败，请重新选择。' }
  reader.readAsDataURL(file)
}

async function saveCat() {
  const name = catDraft.value.name.trim()
  if (!name) {
    saveError.value = '请先填写猫咪名字。'
    return
  }
  if (photoError.value) return

  isSaving.value = true
  saveError.value = ''
  notice.value = ''
  try {
    const response = await fetch(`${apiBaseUrl}/api/cats`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...catDraft.value, name }),
    })
    if (!response.ok) throw new Error(await responseError(response))
    showForm.value = false
    catDraft.value = emptyDraft()
    notice.value = '档案保存好了。'
    await loadCats()
  } catch (error) {
    saveError.value = error instanceof Error
      ? `${error.message}。已保留你填写的内容，可以检查后重试。`
      : '保存失败。已保留你填写的内容，请重试。'
  } finally {
    isSaving.value = false
  }
}

async function openCat(catId: number) {
  page.value = 'detail'
  selectedCatId.value = catId
  selectedCat.value = null
  detailError.value = ''
  await loadCatDetail()
}

async function loadCatDetail() {
  if (selectedCatId.value === null) return
  isLoadingDetail.value = true
  detailError.value = ''
  try {
    const response = await fetch(`${apiBaseUrl}/api/cats/${selectedCatId.value}`)
    if (!response.ok) throw new Error(await responseError(response))
    selectedCat.value = await response.json() as Cat
  } catch (error) {
    detailError.value = error instanceof Error
      ? `${error.message}。请检查连接后重试。`
      : '暂时无法读取这份档案，请重试。'
  } finally {
    isLoadingDetail.value = false
  }
}

function returnToList() {
  page.value = 'list'
  selectedCat.value = null
  selectedCatId.value = null
  detailError.value = ''
}

onMounted(() => {
  // The landing page stays light; the archive is loaded when the user enters it.
})
</script>

<template>
  <main v-if="page === 'home'" class="home-page">
    <header class="site-header">
      <a class="brand" href="#home" aria-label="喵家档案首页">
        <span class="brand-mark" aria-hidden="true">喵</span>
        <span class="brand-word"><strong>喵家档案</strong><small>OUR LITTLE FAMILY</small></span>
      </a>
      <span class="header-note"><span class="live-dot"></span> 给每一份陪伴留个位置</span>
    </header>

    <section id="home" class="home-hero">
      <div class="hero-copy">
        <p class="eyebrow">A LITTLE HOME FOR YOUR CATS</p>
        <h1>把关于它的<br /><em>每一天</em>，好好收藏。</h1>
        <p class="hero-description">为家里的每一位小成员建立档案。名字、生日、性格，还有那些只有家人才懂的小习惯，都有地方好好记录。</p>
        <button class="primary-button hero-button" type="button" @click="enterArchive">
          进入我的猫咪档案 <span aria-hidden="true">↗</span>
        </button>
        <p class="hero-footnote"><span class="tiny-paw">✳</span> 本地保存，关掉页面也不会忘记</p>
      </div>

      <div class="hero-art" aria-label="猫咪档案小插画">
        <div class="art-ring ring-one"></div><div class="art-ring ring-two"></div>
        <div class="sun-circle"></div>
        <div class="cat-illustration" aria-hidden="true">
          <span class="cat-ear ear-a"></span><span class="cat-ear ear-b"></span>
          <span class="cat-face"><i class="cat-eye eye-a"></i><i class="cat-eye eye-b"></i><i class="cat-nose"></i></span>
          <span class="cat-torso"></span><span class="cat-tail"></span><span class="cat-foot foot-a"></span><span class="cat-foot foot-b"></span>
        </div>
        <div class="floating-note note-a"><span class="note-rule"></span> 一只猫，一段故事</div>
        <div class="floating-note note-b"><span class="note-flower">✿</span> 成长 · 陪伴 · 日常</div>
        <span class="art-caption">A HOME FOR EVERY PAW</span>
      </div>
    </section>

    <section class="feature-strip" aria-label="项目功能">
      <article><span class="feature-index">01</span><div><h2>建立档案</h2><p>姓名、照片、生日与性格</p></div></article>
      <article><span class="feature-index">02</span><div><h2>认识每一只</h2><p>多只猫咪，分别记录与查看</p></div></article>
      <article><span class="feature-index">03</span><div><h2>一直记得</h2><p>保存在本机，下次打开还在</p></div></article>
    </section>
    <footer class="site-footer"><span>MADE WITH LOVE FOR OUR LITTLE FAMILY</span><span>一份档案，收藏一份陪伴 <b>♥</b></span></footer>
  </main>

  <main v-else class="archive-page">
    <header class="site-header archive-header">
      <a class="brand" href="#home" aria-label="返回喵家档案首页" @click.prevent="returnHome">
        <span class="brand-mark" aria-hidden="true">喵</span>
        <span class="brand-word"><strong>喵家档案</strong><small>OUR LITTLE FAMILY</small></span>
      </a>
      <button class="text-button" type="button" @click="returnHome">← 返回首页</button>
    </header>

    <section v-if="page === 'list'" class="archive-content">
      <div class="section-heading">
        <div>
          <p class="eyebrow">THE FAMILY ARCHIVE</p>
          <h1>家里的小成员<span>.</span></h1>
          <p class="section-subtitle">{{ catCount ? `已经为 ${catCount} 位小成员留下档案。` : '从第一份档案开始，记录它来到家里的每一天。' }}</p>
        </div>
        <button class="primary-button" type="button" @click="openCreateForm">＋ 创建猫咪档案</button>
      </div>

      <p v-if="notice" class="notice-banner" role="status">{{ notice }}</p>

      <div v-if="isLoading" class="state-panel" role="status"><span class="spinner"></span><span>正在打开档案柜…</span></div>
      <div v-else-if="listError" class="state-panel error-panel" role="alert">
        <span class="state-icon">!</span><div><h2>档案暂时打不开</h2><p>{{ listError }}</p><button class="secondary-button" type="button" @click="loadCats">重新加载</button></div>
      </div>
      <div v-else-if="cats.length === 0" class="empty-panel">
        <div class="empty-cat" aria-hidden="true"><span>喵</span></div>
        <p class="eyebrow">A BLANK PAGE, A NEW STORY</p>
        <h2>第一份猫咪档案，等你来写</h2>
        <p>添加姓名、照片和小资料，下次打开时也能继续查看。</p>
        <button class="primary-button" type="button" @click="openCreateForm">创建第一份档案 <span aria-hidden="true">↗</span></button>
      </div>
      <div v-else class="cat-grid">
        <button v-for="cat in cats" :key="cat.id" class="cat-card" type="button" @click="openCat(cat.id)">
          <div class="cat-card-photo">
            <img v-if="cat.photo_data" :src="cat.photo_data" :alt="`${cat.name}的照片`" />
            <div v-else class="photo-placeholder" aria-hidden="true"><span>喵</span></div>
            <span class="photo-index">NO. {{ String(cat.id).padStart(2, '0') }}</span>
          </div>
          <div class="cat-card-copy">
            <div class="cat-card-title"><h2>{{ cat.name }}</h2><span aria-hidden="true">↗</span></div>
            <p>{{ cat.breed || '品种还没有填写' }}</p>
            <div class="cat-card-meta"><span>{{ cat.gender || '性别未填写' }}</span><span v-if="cat.birthday">生日 {{ cat.birthday }}</span></div>
          </div>
        </button>
        <button class="add-card" type="button" @click="openCreateForm"><span>＋</span><strong>认识一位新成员</strong><small>继续添加猫咪档案</small></button>
      </div>
    </section>

    <section v-else class="detail-content">
      <button class="text-button back-button" type="button" @click="returnToList">← 返回档案列表</button>
      <div v-if="isLoadingDetail" class="state-panel" role="status"><span class="spinner"></span><span>正在打开这份档案…</span></div>
      <div v-else-if="detailError" class="state-panel error-panel" role="alert">
        <span class="state-icon">!</span><div><h2>这份档案暂时打不开</h2><p>{{ detailError }}</p><button class="secondary-button" type="button" @click="loadCatDetail">重新尝试</button></div>
      </div>
      <article v-else-if="selectedCat" class="detail-card">
        <div class="detail-photo">
          <img v-if="selectedCat.photo_data" :src="selectedCat.photo_data" :alt="`${selectedCat.name}的照片`" />
          <div v-else class="photo-placeholder detail-placeholder" aria-hidden="true"><span>喵</span></div>
          <span class="detail-photo-caption">A MEMBER OF OUR FAMILY</span>
        </div>
        <div class="detail-info">
          <p class="eyebrow">CAT PROFILE · NO. {{ String(selectedCat.id).padStart(2, '0') }}</p>
          <h1>{{ selectedCat.name }}</h1>
          <p class="detail-lead">{{ selectedCat.personality || '每一只猫，都有自己的小故事。' }}</p>
          <div class="detail-facts">
            <div><span>品种</span><strong>{{ selectedCat.breed || '暂未填写' }}</strong></div>
            <div><span>生日</span><strong>{{ selectedCat.birthday || '暂未填写' }}</strong></div>
            <div><span>性别</span><strong>{{ selectedCat.gender || '暂未填写' }}</strong></div>
            <div><span>加入档案</span><strong>{{ new Date(selectedCat.created_at).toLocaleDateString('zh-CN') }}</strong></div>
          </div>
          <section v-if="selectedCat.notes" class="detail-notes"><span>想记住的事</span><p>{{ selectedCat.notes }}</p></section>
          <button class="primary-button detail-add" type="button" @click="returnToList(); openCreateForm()">＋ 再添加一只猫</button>
        </div>
      </article>
    </section>

    <footer class="site-footer"><span>MADE WITH LOVE FOR OUR LITTLE FAMILY</span><span>档案保存在本机 <b>♥</b></span></footer>

    <div v-if="showForm" class="modal-backdrop" @click.self="closeCreateForm">
      <section class="form-modal" role="dialog" aria-modal="true" aria-labelledby="form-title">
        <header class="modal-header">
          <div><p class="eyebrow">A NEW FAMILY MEMBER</p><h2 id="form-title">创建猫咪档案</h2></div>
          <button class="close-button" type="button" aria-label="关闭表单" :disabled="isSaving" @click="closeCreateForm">×</button>
        </header>
        <p class="form-intro">先从名字开始，其他小资料可以慢慢补充。</p>
        <form class="cat-form" @submit.prevent="saveCat">
          <label class="photo-picker">
            <input type="file" accept="image/*" @change="choosePhoto" />
            <img v-if="catDraft.photo_data" :src="catDraft.photo_data" alt="猫咪照片预览" />
            <span v-else class="photo-picker-placeholder"><b>＋</b><small>添加照片<br />最多 2 MB</small></span>
            <span class="photo-picker-caption">{{ catDraft.photo_data ? '更换照片' : '选择照片（选填）' }}</span>
          </label>
          <p v-if="photoError" class="field-error" role="alert">{{ photoError }}</p>

          <label class="form-field"><span>猫咪名字 <b>*</b></span><input v-model="catDraft.name" required maxlength="60" placeholder="比如：小橘" autocomplete="off" /></label>
          <div class="form-row">
            <label class="form-field"><span>品种</span><input v-model="catDraft.breed" maxlength="80" placeholder="比如：中华田园猫" /></label>
            <label class="form-field"><span>生日</span><input v-model="catDraft.birthday" type="date" /></label>
          </div>
          <label class="form-field"><span>性别</span><select v-model="catDraft.gender"><option value="">暂不填写</option><option value="公">公</option><option value="母">母</option><option value="未知">还不知道</option></select></label>
          <label class="form-field"><span>性格和小习惯</span><textarea v-model="catDraft.personality" maxlength="500" rows="3" placeholder="比如：喜欢晒太阳，听到零食袋就会跑来。"></textarea></label>
          <label class="form-field"><span>想记住的事</span><textarea v-model="catDraft.notes" maxlength="1000" rows="2" placeholder="选填"></textarea></label>
          <p v-if="saveError" class="form-error" role="alert">{{ saveError }}</p>
          <div class="form-actions">
            <button class="secondary-button" type="button" :disabled="isSaving" @click="closeCreateForm">取消</button>
            <button class="primary-button" type="submit" :disabled="isSaving || Boolean(photoError)"><span v-if="isSaving" class="button-spinner"></span>{{ isSaving ? '正在保存…' : '保存这份档案' }}</button>
          </div>
        </form>
      </section>
    </div>
  </main>
</template>
