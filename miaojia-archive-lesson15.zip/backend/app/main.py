from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


DEFAULT_DB_PATH = Path(__file__).resolve().parent.parent / "data" / "cats.sqlite3"
DB_PATH = Path(os.environ.get("MIAOJIA_DB_PATH", DEFAULT_DB_PATH))

app = FastAPI(title="喵家档案 API", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


class CatCreate(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    breed: str = Field(default="", max_length=80)
    birthday: str = Field(default="", max_length=20)
    gender: str = Field(default="未填写", max_length=12)
    personality: str = Field(default="", max_length=500)
    notes: str = Field(default="", max_length=1000)
    photo_data: str = Field(default="", max_length=3_000_000)


class CatRecord(CatCreate):
    id: int
    created_at: str


def connect_db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS cats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            breed TEXT NOT NULL DEFAULT '',
            birthday TEXT NOT NULL DEFAULT '',
            gender TEXT NOT NULL DEFAULT '未填写',
            personality TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '',
            photo_data TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        )
        """
    )
    connection.commit()
    return connection


def row_to_cat(row: sqlite3.Row) -> CatRecord:
    return CatRecord(**dict(row))


@app.get("/api/health")
def health_check() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/cats", response_model=list[CatRecord])
def list_cats() -> list[CatRecord]:
    with closing(connect_db()) as connection:
        rows = connection.execute("SELECT * FROM cats ORDER BY id DESC").fetchall()
    return [row_to_cat(row) for row in rows]


@app.post("/api/cats", response_model=CatRecord, status_code=status.HTTP_201_CREATED)
def create_cat(cat: CatCreate) -> CatRecord:
    name = cat.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="请填写猫咪名字。")

    values = cat.model_dump()
    values["name"] = name
    values["created_at"] = datetime.now(timezone.utc).isoformat()
    with closing(connect_db()) as connection:
        cursor = connection.execute(
            """
            INSERT INTO cats (name, breed, birthday, gender, personality, notes, photo_data, created_at)
            VALUES (:name, :breed, :birthday, :gender, :personality, :notes, :photo_data, :created_at)
            """,
            values,
        )
        connection.commit()
        row = connection.execute("SELECT * FROM cats WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return row_to_cat(row)


@app.get("/api/cats/{cat_id}", response_model=CatRecord)
def get_cat(cat_id: int) -> CatRecord:
    with closing(connect_db()) as connection:
        row = connection.execute("SELECT * FROM cats WHERE id = ?", (cat_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="没有找到这只猫咪的档案。")
    return row_to_cat(row)
