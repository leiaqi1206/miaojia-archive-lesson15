import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

from app import main


class CatArchiveApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_patch = patch.object(main, "DB_PATH", Path(self.temp_dir.name) / "test-cats.sqlite3")
        self.db_patch.start()
        self.client = TestClient(main.app)

    def tearDown(self) -> None:
        self.client.close()
        self.db_patch.stop()
        self.temp_dir.cleanup()

    def test_health_check(self) -> None:
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_create_list_and_open_cat_profile(self) -> None:
        payload = {
            "name": "小橘",
            "breed": "中华田园猫",
            "birthday": "2024-03-12",
            "gender": "公",
            "personality": "亲人，喜欢晒太阳",
            "notes": "最喜欢冻干。",
        }
        created = self.client.post("/api/cats", json=payload)
        self.assertEqual(created.status_code, 201)
        cat_id = created.json()["id"]

        self.assertEqual(self.client.get("/api/cats").json()[0]["name"], "小橘")
        detail = self.client.get(f"/api/cats/{cat_id}")
        self.assertEqual(detail.status_code, 200)
        self.assertEqual(detail.json()["personality"], "亲人，喜欢晒太阳")

    def test_profile_persists_after_reopening_client(self) -> None:
        created = self.client.post("/api/cats", json={"name": "奶盖"})
        self.assertEqual(created.status_code, 201)
        cat_id = created.json()["id"]

        self.client.close()
        with TestClient(main.app) as reopened_client:
            response = reopened_client.get(f"/api/cats/{cat_id}")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["name"], "奶盖")

    def test_photo_data_is_saved_with_profile(self) -> None:
        photo_data = "data:image/png;base64,aGVsbG8="
        created = self.client.post(
            "/api/cats",
            json={"name": "有照片的猫", "photo_data": photo_data},
        )

        self.assertEqual(created.status_code, 201)
        self.assertEqual(created.json()["photo_data"], photo_data)

    def test_blank_name_is_rejected(self) -> None:
        response = self.client.post("/api/cats", json={"name": "   "})
        self.assertEqual(response.status_code, 422)

    def test_missing_profile_returns_not_found(self) -> None:
        self.assertEqual(self.client.get("/api/cats/999").status_code, 404)


if __name__ == "__main__":
    unittest.main()
