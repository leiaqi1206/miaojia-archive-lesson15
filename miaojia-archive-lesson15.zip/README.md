# 喵家档案

Lesson15 作业项目：为家里的猫咪建立档案、查看多只猫，并在再次打开项目后继续查看保存的资料。

## 已实现

- 从首页进入猫咪档案库，也可以返回首页。
- 新建档案：姓名必填；可以填写照片、品种、生日、性别、性格和备注。
- 查看多只猫的档案列表，打开单只猫的详细资料。
- 照片在浏览器中选择后保存为图片数据，档案和照片都写入本地 SQLite 数据库。
- 加载、保存成功、保存失败、读取失败和重试状态都有界面反馈。
- 后端提供 `GET /api/health`、`GET /api/cats`、`POST /api/cats` 和 `GET /api/cats/{id}`。

## 环境要求

- Node.js 20 或更新版本（包含 npm）
- Python 3.10 或更新版本

## 启动后端

在第一个终端中，从项目根目录运行：

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
uvicorn app.main:app --reload
```

后端地址：<http://127.0.0.1:8000>

- 健康检查：<http://127.0.0.1:8000/api/health>
- API 交互文档：<http://127.0.0.1:8000/docs>
- SQLite 文件：首次启动后自动创建 `backend/data/cats.sqlite3`

## 启动前端

另开第二个终端，在项目根目录运行：

```bash
cd frontend
npm install
npm run dev
```

打开终端显示的地址，默认是 <http://localhost:5173>。

## 操作验证

1. 打开首页，点击“进入我的猫咪档案”。
2. 点击“创建猫咪档案”，填写“小橘”的姓名及其他资料并保存。
3. 再添加“奶盖”，确认列表里显示两只猫。
4. 打开每只猫的详情，确认资料和照片显示正确。
5. 刷新页面，或关闭后重新启动前后端，再打开档案库；两只猫的资料仍应存在。
6. 停止后端后重试加载，页面应显示错误和重试入口；重新启动后端再重试。

运行后端测试：

```bash
cd backend
source .venv/bin/activate
python -m unittest discover -s tests -v
```

## 当前范围

当前版本不包含登录、权限管理、档案编辑/删除、疫苗与就诊记录、生产部署。档案保存在本机 SQLite 文件中，仅供本地作业演示。

## 提交前补充

- GitHub 仓库链接：<https://github.com/leiaqi1206/miaojia-archive-lesson15>
- 截图或演示：展示新增两只猫、查看详情、重新打开后资料仍在
- 已完成内容：新增、列表、详情和本地持久保存
- 后续完善：登录、档案编辑/删除、健康记录和生产部署
